websites = [('facebook', 'https://www.facebook.com'),
            ('gmail', 'https://gmail.com'),
            ('thenewboston', 'https://www.thenewboston.com'),
            ('reddit', 'https://reddit.com'),
            ('linkedin', 'https://linkedin.com'),

        ]
